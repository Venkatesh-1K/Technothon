package com.login.RegisterLogin.service;


import com.login.RegisterLogin.dto.LabDTO;
import com.login.RegisterLogin.dto.LoginDTO;
import com.login.RegisterLogin.response.LoginMessage;

public interface LabService {

	

	public LoginMessage loginLab(LoginDTO loginDTO);

	public String saveEmployee(LabDTO labDTO);


	

}
