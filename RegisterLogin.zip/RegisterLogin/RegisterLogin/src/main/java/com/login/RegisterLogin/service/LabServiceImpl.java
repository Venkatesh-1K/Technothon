package com.login.RegisterLogin.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.login.RegisterLogin.dto.LabDTO;
import com.login.RegisterLogin.dto.LoginDTO;
import com.login.RegisterLogin.entity.LabEntity;
import com.login.RegisterLogin.repository.LabRepository;
import com.login.RegisterLogin.response.LoginMessage;

@Service
public class LabServiceImpl implements LabService {
	
	@Autowired
	private LabRepository repository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public String saveEmployee(LabDTO labDTO) {
		LabEntity lab = new LabEntity();
		lab.getId();
		lab.getName();
		lab.getEmailid();
		this.passwordEncoder.encode(labDTO.getPassword());
		repository.save(lab);
		return lab.getName();
	}
	
	LabDTO labDTO;

	@Override
	public LoginMessage loginLab(LoginDTO loginDTO) {
		String msg = "";
        LabEntity lab = repository.findByEmailid(loginDTO.getEmailid());
        if (lab != null) {
            String password = loginDTO.getPassword();
            String encodedPassword = lab.getPassword();
            Boolean isPwdRight = passwordEncoder.matches(password, encodedPassword);
            if (isPwdRight) {
                Optional<LabEntity> lab2 = repository.findOneByEmailidAndPassword(loginDTO.getEmailid(), encodedPassword);
                if (lab2.isPresent()) {
                    return new LoginMessage("Login Success", true);
                } else {
                    return new LoginMessage("Login Failed", false);
                }
            } else {
 
                return new LoginMessage("password Not Match", false);
            }
        }else {
            return new LoginMessage("Email not exits", false);
        }
 
 
    }

	
		
	}


