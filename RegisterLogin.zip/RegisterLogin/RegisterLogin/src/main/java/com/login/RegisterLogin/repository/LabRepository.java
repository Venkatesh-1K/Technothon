package com.login.RegisterLogin.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.login.RegisterLogin.entity.LabEntity;
@Repository
@EnableJpaRepositories
public interface LabRepository extends JpaRepository<LabEntity, Long> {
	Optional<LabEntity> findOneByEmailidAndPassword(String emailid, String password);
	
	LabEntity findByEmailid(String email);
	
	
}
