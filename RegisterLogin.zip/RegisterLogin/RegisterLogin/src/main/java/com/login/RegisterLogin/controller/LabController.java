package com.login.RegisterLogin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.login.RegisterLogin.dto.LabDTO;
import com.login.RegisterLogin.dto.LoginDTO;
import com.login.RegisterLogin.response.LoginMessage;
import com.login.RegisterLogin.service.LabService;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class LabController {
	
	@Autowired
	LabService service;
	
	@PostMapping("/save")
	public String saveEmployee(@RequestBody LabDTO labDTO) {
		String id = service.saveEmployee(labDTO);
		return id;
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> loginLab(@RequestBody LoginDTO loginDTO){
		LoginMessage message = service.loginLab(loginDTO);
		return ResponseEntity.ok(message);
	}

}
